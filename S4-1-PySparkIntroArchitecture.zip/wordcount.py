lines = sc.textFile("/FileStore/tables/SparkRDD/war_and_peace.txt",4)

type(lines)

lines.count()

lines.first()

type(lines.first())

lines.getNumPartitions()

def count_in_a_partition(iterator):
    yield sum(1 for _ in iterator)

lines.mapPartitions(count_in_a_partition).collect()

lines.take(5)

nonNullLines = lines.filter(lambda line: len(line)>0)
type(nonNullLines)

nonNullLines.count()

nonNullLines.first()

type(nonNullLines.first())

nonNullLines.take(5)

nonNullLines.getNumPartitions()

nonNullLines.mapPartitions(count_in_a_partition).collect()

words = nonNullLines.flatMap(lambda line: line.split())
type(words)

words.first()

words.take(11)

words.count()

words.getNumPartitions()

upperWords = words.map(lambda word: word.upper())
type(upperWords)

upperWords.count()

upperWords.getNumPartitions()

upperWords.first()

upperWords.take(11)

pairedOnes = upperWords.map(lambda uw: (uw, 1))
type(pairedOnes)

pairedOnes.first()

pairedOnes.take(11)

type(pairedOnes.first())

type(pairedOnes)

wordCounts = pairedOnes.reduceByKey(lambda p, n: p + n)
type(wordCounts)

wordCounts.count()

wordCounts.first()

wordCounts.take(5)

wordCounts.getNumPartitions()
