%fs help

%fs ls /FileStore/tables

%fs cp /FileStore/tables/file1.txt /FileStore/tables/file2.txt

%fs rm /FileStore/tables/file1.txt

%fs mv /FileStore/tables/file2.txt /FileStore/tables/file1.txt

%fs rm -r /FileStore/tables/mydir/

dbutils.fs.help()

display(dbutils.fs.ls("/FileStore/tables"))

dbutils.fs.cp("/FileStore/tables/file1.txt", "/FileStore/tables/file2.txt")

dbutils.fs.rm("/FileStore/tables/file1.txt")

dbutils.fs.mv("/FileStore/tables/file2.txt", "/FileStore/tables/file1.txt")

dbutils.fs.rm("/FileStore/tables/mydir/", recurse=True)
