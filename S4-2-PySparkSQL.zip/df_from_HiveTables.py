# Instatiate SparkSession with Hive support if required depending on the implementation and configuration ofSpark & Hive on your cluster
# Note that in most of the recent versions of Spark & Hive this is not required as they are seamlessly integrated

# spark = SparkSession.builder.appName("Python Spark SQL example").config("spark.sql.warehouse.dir", "hdfs://<hostname>:<portnum>/user/hive/warehouse").enableHiveSupport().getOrCreate()

spark.sql("SELECT * FROM retaildb1.customers1").show()

spark.sql("SELECT * FROM retaildb1.products1").show()

cStateCount50 = spark.sql("SELECT customer_state, count(*) as state_count FROM retaildb1.customers1 GROUP BY customer_state HAVING state_count>=50")

# Output of a Hive query will be a DataFrame 

type(cStateCount50)

cStateCount50.printSchema()

cStateCount50.show()

prd200 = spark.sql("SELECT category_id, product_category, count(*) as prdcount FROM retaildb1.products1 WHERE product_price>200 GROUP BY category_id, product_category ORDER BY product_category")

type(prd200)

prd200.show()

prd200.printSchema()

# These dataframes can be written to Hive tables after creating a new database. The following lines show the syntax. Plesae note that the Hive metastore version should be compatible with the Spark version to be able to create databases and tables in Hive.

# spark.sql("CREATE DATABASE IF NOT EXISTS retaildb1")

cStateCount50.coalesce(1).write.saveAsTable("retaildb1.cStateCount50")

prd200.coalesce(1).write.saveAsTable("retaildb1.prd200")
