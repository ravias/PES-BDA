#!/usr/bin/env python3
import sys
 
#--- get each line from stdin ---
for line in sys.stdin:
    words = line.split()

    #--- output tuples [word, 1] in tab-delimited format---
    for word in words:
        uword = word.upper()
        print('%s\t%s' % (uword, "1"))
