# Prior to running this application, run the kafka producer.
# You can use the command $ python Stock_Price_KafkaProducer.py &
# Make sure the file stock_stream_data.csv is available in the same directory.
# The producer reads the file stock_stream_data.csv and publishes 10 lines of the file at a time to the specified topic at the intervals of 2 seconds.
# This forms our streaming data which our alert application reads as soon as the data is generated and displays the alert.
# You need to run the alert application i.e. pyspark structured streaming application as given below.

# spark-submit --master local[*] --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.1.2 Stock_Price_Alert_Kafka.py

# Import the necessary classes
import pyspark
from pyspark.sql import SparkSession

# Create a SparkSession, the starting point of all functionalities related to Spark.

spark = SparkSession.builder.appName("StructuredStreaming Kafka Exercise").getOrCreate()

from pyspark.sql.functions import *
from pyspark.sql.types import *

# Define the schema for the static file of previous max price
schema1 = StructType([
                    StructField("symbol1", StringType(), False),
                    StructField("prevmaxprice", DoubleType(), False)
                    ])

# Load the file into a dataframe
prevmaxdf = spark.read.csv('file:///home/hadoop/structstream/previous_max_price.csv', schema=schema1)

prevmaxdf.printSchema()
prevmaxdf.show(5)

# Get the messages from the kafka topic
kfstreamdf1 = spark.readStream.format("kafka").option("kafka.bootstrap.servers", "localhost:9092").option("subscribe", "stock-topic").load()

# Extract only the value part of the message (discard key, topic name, partition, offset, timestamp etc fields)
kfstreamdf2=kfstreamdf1.selectExpr("CAST(value AS STRING)")

# Split the value into the required fields
kfstreamdf3=kfstreamdf2.withColumn('symbol2',split(kfstreamdf2['value'],',',).getItem(0))\
.withColumn('tstamp',split(kfstreamdf2['value'],',',).getItem(1))\
.withColumn('currentprice',split(kfstreamdf2['value'],',',).getItem(2))

kfstreamdf4=kfstreamdf3.select('symbol2','tstamp','currentprice')

joindf=kfstreamdf4.join(prevmaxdf,kfstreamdf4.symbol2==prevmaxdf.symbol1)

filtereddf=joindf.where(joindf.currentprice>=joindf.prevmaxprice)

filtereddf.writeStream.format('console').start().awaitTermination()
